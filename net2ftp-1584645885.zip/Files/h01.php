<h1>opdracht: 1</h1>
<?php
$a = "Ik heb niet gefaald";
$b = "die niet werken";
$c = "10000";
$volledige_zin_opdr01 = $a." ik heb alleen ".$c." manieren gevonden ".$b;

echo "$volledige_zin_opdr01";
?>

<h1>opdracht: 2</h1>
<?php
$a = "die geen fout";
$b = "en";
$c = "niet.";

$volledige_zin_opdr02 = "mensen ".$a."en maken, werken ".$c;

echo "$volledige_zin_opdr02";
?>

<h1>opdracht: 3</h1>
<?php
$a = "ry";
$b = ", but";
$c = "fail";
$volledige_zin_opdr03 = "T".$a." and ".$c.$b." never ".$c." to T".$a.".";

echo "$volledige_zin_opdr03";
?>

<h1>Opdracht: 4</h1>
<?php
$a = "\"omgaan";
$b = "met";
$c = "teleu";
$volledige_zin_opdr04 = "De cursus ".$a.$b.$c."rstellingen\" "."kan vanavond helaas niet doorgaan.";

echo "$volledige_zin_opdr04";
?>
<br>
<br>
<a href="../index.php"><button>Index</button></a>




